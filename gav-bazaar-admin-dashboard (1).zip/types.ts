
export interface NavItem {
  path: string;
  name: string;
  icon?: (props: IconProps) => JSX.Element; // Changed from React.ReactNode
}

export interface IconProps {
  className?: string;
}

export enum OrderStatus {
  PENDING = 'Pending',
  PROCESSING = 'Processing',
  SHIPPED = 'Shipped',
  DELIVERED = 'Delivered',
  CANCELLED = 'Cancelled',
  COMPLETED = 'Completed',
}

export enum UserStatus {
  ACTIVE = 'Active',
  INACTIVE = 'Inactive',
  PAID = 'Paid',
  UNPAID = 'Unpaid',
}

export interface OrderItem {
  id: string;
  productId: string;
  productName: string;
  quantity: number;
  price: number;
  imageUrl?: string;
}

export interface ShippingAddress {
  street: string;
  city: string;
  state: string;
  zip: string;
  country: string;
}

export interface Order {
  id: string;
  userId: string;
  userName?: string; 
  orderDate: string;
  status: OrderStatus;
  totalAmount: number;
  items: OrderItem[];
  shippingAddress: ShippingAddress;
}

export interface User {
  id: string;
  name: string;
  email: string;
  joinDate: string;
  status: UserStatus; 
  avatarUrl?: string;
  wishlist?: Product[];
  orders?: Pick<Order, 'id' | 'orderDate' | 'status' | 'totalAmount'>[];
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  stock: number;
  categoryId: string;
  categoryName?: string;
  brandId?: string;
  brandName?: string;
  vendorId?: string;
  vendorName?: string;
  imageUrl?: string;
  sku: string;
  tags?: string[];
}

export interface Category {
  id: string;
  name: string;
  description?: string;
  productCount?: number;
}

export interface Brand {
  id: string;
  name: string;
  logoUrl?: string;
  productCount?: number;
}

export interface Vendor {
  id: string;
  name: string;
  contactEmail: string;
  phone?: string;
  productCount?: number;
}

export interface ColumnDefinition<T> {
  header: string;
  accessor: keyof T | string; // Allow string for nested or custom accessors
  render?: (item: T) => React.ReactNode;
}

export interface OptionType {
  value: string;
  label: string;
}

export type CrudType = 'Product' | 'Category' | 'Brand' | 'Vendor';

// --- Prop type for GenericCrudPage in pages.tsx ---
export interface CrudPageProps<T extends { id: string; name?: string }> {
  title: string;
  itemType: CrudType;
  service: {
    getAll: () => Promise<T[]>;
    getById: (id: string) => Promise<T | undefined>;
    create: (data: Omit<T, 'id'>) => Promise<T>;
    update: (id: string, data: Partial<T>) => Promise<T | undefined>;
    delete: (id: string) => Promise<boolean>;
  };
  columns: ColumnDefinition<T>[];
  getFormFields: (
    currentData: Partial<T>,
    updateField: <K extends keyof T>(name: K, value: T[K] | T[K][]) => void, // Updated signature
    options?: any
  ) => React.ReactNode;
  initialFormData: Partial<T>; // Changed from Omit<T, 'id'>
  additionalDataForForms?: () => Promise<any>;
}
