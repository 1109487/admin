
import type { Order, User, Product, Category, Brand, Vendor, OrderStatus, UserStatus } from './types';
import { OrderStatus as OrderStatusEnum, UserStatus as UserStatusEnum } from './types'; // Import enums for use

// Helper to generate unique IDs
const generateId = () => Math.random().toString(36).substr(2, 9);

// Mock Data Storage
let mockCategories: Category[] = [
  { id: 'cat1', name: 'Electronics', description: 'Gadgets and devices', productCount: 2 },
  { id: 'cat2', name: 'Books', description: 'Fiction and non-fiction', productCount: 1 },
  { id: 'cat3', name: 'Clothing', description: 'Apparel for all ages', productCount: 0 },
];

let mockBrands: Brand[] = [
  { id: 'brand1', name: 'TechCorp', logoUrl: 'https://picsum.photos/seed/brand1/40/40', productCount: 1 },
  { id: 'brand2', name: 'Bookish', logoUrl: 'https://picsum.photos/seed/brand2/40/40', productCount: 1 },
  { id: 'brand3', name: 'Fashionista', logoUrl: 'https://picsum.photos/seed/brand3/40/40', productCount: 0 },
];

let mockVendors: Vendor[] = [
  { id: 'vendor1', name: 'Global Electronics Supplier', contactEmail: 'sales@globalelectronics.com', productCount: 1 },
  { id: 'vendor2', name: 'The Book Nook', contactEmail: 'info@thebooknook.com', productCount: 1 },
];

let mockProducts: Product[] = [
  { 
    id: 'prod1', name: 'Smartphone X', description: 'Latest model smartphone', 
    price: 699.99, stock: 50, categoryId: 'cat1', categoryName: 'Electronics',
    brandId: 'brand1', brandName: 'TechCorp', vendorId: 'vendor1', vendorName: 'Global Electronics Supplier',
    imageUrl: 'https://picsum.photos/seed/prod1/200/200', sku: 'SPX-001', tags: ['mobile', 'latest']
  },
  { 
    id: 'prod2', name: 'Wireless Headphones', description: 'Noise-cancelling headphones', 
    price: 199.99, stock: 100, categoryId: 'cat1', categoryName: 'Electronics',
    brandId: 'brand1', brandName: 'TechCorp', vendorId: 'vendor1', vendorName: 'Global Electronics Supplier',
    imageUrl: 'https://picsum.photos/seed/prod2/200/200', sku: 'WHP-002', tags: ['audio', 'bluetooth']
  },
  { 
    id: 'prod3', name: 'The Great Novel', description: 'A best-selling novel', 
    price: 19.99, stock: 200, categoryId: 'cat2', categoryName: 'Books',
    brandId: 'brand2', brandName: 'Bookish', vendorId: 'vendor2', vendorName: 'The Book Nook',
    imageUrl: 'https://picsum.photos/seed/prod3/200/200', sku: 'BKN-001', tags: ['fiction', 'bestseller']
  },
];

let mockUsers: User[] = [
  { 
    id: 'user1', name: 'Alice Wonderland', email: 'alice@example.com', 
    joinDate: '2023-01-15', status: UserStatusEnum.ACTIVE, 
    avatarUrl: 'https://picsum.photos/seed/user1/50/50',
    wishlist: [mockProducts[0]],
    orders: [{id: 'order1', orderDate: '2023-03-01', status: OrderStatusEnum.DELIVERED, totalAmount: 699.99}]
  },
  { 
    id: 'user2', name: 'Bob The Builder', email: 'bob@example.com', 
    joinDate: '2023-02-20', status: UserStatusEnum.PAID, 
    avatarUrl: 'https://picsum.photos/seed/user2/50/50',
    wishlist: [mockProducts[1], mockProducts[2]],
    orders: [{id: 'order2', orderDate: '2023-04-10', status: OrderStatusEnum.PENDING, totalAmount: 219.98}]
  },
];

let mockOrders: Order[] = [
  { 
    id: 'order1', userId: 'user1', userName: 'Alice Wonderland', orderDate: '2023-03-01', 
    status: OrderStatusEnum.DELIVERED, totalAmount: 699.99,
    items: [{ id: 'item1', productId: 'prod1', productName: 'Smartphone X', quantity: 1, price: 699.99, imageUrl: mockProducts[0].imageUrl }],
    shippingAddress: { street: '123 Main St', city: 'Anytown', state: 'CA', zip: '90210', country: 'USA' }
  },
  { 
    id: 'order2', userId: 'user2', userName: 'Bob The Builder', orderDate: '2023-04-10', 
    status: OrderStatusEnum.PENDING, totalAmount: 219.98,
    items: [
      { id: 'item2', productId: 'prod2', productName: 'Wireless Headphones', quantity: 1, price: 199.99, imageUrl: mockProducts[1].imageUrl },
      { id: 'item3', productId: 'prod3', productName: 'The Great Novel', quantity: 1, price: 19.99, imageUrl: mockProducts[2].imageUrl }
    ],
    shippingAddress: { street: '456 Oak Ave', city: 'Otherville', state: 'NY', zip: '10001', country: 'USA' }
  },
];

// Generic CRUD functions
const createService = <T extends { id: string }>(dataStore: T[]) => ({
  getAll: async (): Promise<T[]> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 300));
    return [...dataStore];
  },
  getById: async (id: string): Promise<T | undefined> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    return dataStore.find(item => item.id === id);
  },
  create: async (itemData: Omit<T, 'id'>): Promise<T> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const newItem = { ...itemData, id: generateId() } as T;
    dataStore.push(newItem);
    return newItem;
  },
  update: async (id: string, updatedData: Partial<T>): Promise<T | undefined> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const itemIndex = dataStore.findIndex(item => item.id === id);
    if (itemIndex > -1) {
      dataStore[itemIndex] = { ...dataStore[itemIndex], ...updatedData };
      return dataStore[itemIndex];
    }
    return undefined;
  },
  delete: async (id: string): Promise<boolean> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const initialLength = dataStore.length;
    const newDataStore = dataStore.filter(item => item.id !== id);
    // This reassignment is tricky for the exported array if it's not handled carefully.
    // For simplicity here, we'll replace the array content.
    dataStore.length = 0; // Clear original array
    Array.prototype.push.apply(dataStore, newDataStore); // Push new content
    return dataStore.length < initialLength;
  },
});

// Specific services
export const productService = createService<Product>(mockProducts);
export const categoryService = createService<Category>(mockCategories);
export const brandService = createService<Brand>(mockBrands);
export const vendorService = createService<Vendor>(mockVendors);

// Custom services for Orders and Users due to more complex relations or specific needs
export const orderService = {
  getAll: async (): Promise<Order[]> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    // Enrich orders with userName if not present
    return mockOrders.map(order => {
      if (!order.userName) {
        const user = mockUsers.find(u => u.id === order.userId);
        return { ...order, userName: user ? user.name : 'Unknown User' };
      }
      return order;
    });
  },
  getById: async (id: string): Promise<Order | undefined> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const order = mockOrders.find(o => o.id === id);
    if (order && !order.userName) {
      const user = mockUsers.find(u => u.id === order.userId);
      return { ...order, userName: user ? user.name : 'Unknown User' };
    }
    return order;
  },
  updateStatus: async (id: string, status: OrderStatus): Promise<Order | undefined> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const orderIndex = mockOrders.findIndex(o => o.id === id);
    if (orderIndex > -1) {
      mockOrders[orderIndex].status = status;
      return mockOrders[orderIndex];
    }
    return undefined;
  }
  // Create/Delete for orders might be more complex (e.g., affecting product stock)
  // For this admin panel, focusing on viewing and status updates.
};

export const userService = {
  getAll: async (): Promise<User[]> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    return [...mockUsers];
  },
  getById: async (id: string): Promise<User | undefined> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const user = mockUsers.find(u => u.id === id);
    if (user) {
      // Simulate fetching full user details, e.g., enriching orders or wishlist
      return {
        ...user,
        orders: mockOrders.filter(o => o.userId === id).map(o => ({ id: o.id, orderDate: o.orderDate, status: o.status, totalAmount: o.totalAmount })),
        wishlist: user.wishlist || [], // Ensure wishlist is an array
      };
    }
    return undefined;
  },
  // CRUD for users can be added here if needed
};

// Helper for summary data (Dashboard)
export const getDashboardSummary = async () => {
  await new Promise(resolve => setTimeout(resolve, 300));
  return {
    totalOrders: mockOrders.length,
    pendingOrders: mockOrders.filter(o => o.status === OrderStatusEnum.PENDING).length,
    totalUsers: mockUsers.length,
    totalProducts: mockProducts.length,
    lowStockProducts: mockProducts.filter(p => p.stock < 10).length,
    recentOrders: mockOrders.slice(0, 5).map(order => {
        const user = mockUsers.find(u => u.id === order.userId);
        return { ...order, userName: user ? user.name : 'Unknown User' };
      }),
  };
};

// Helper to get products by category ID
export const getProductsByCategoryId = async (categoryId: string): Promise<Product[]> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    return mockProducts.filter(p => p.categoryId === categoryId);
};

// Helper to get product options for forms
export const getProductOptions = async (): Promise<{ value: string, label: string }[]> => {
  const products = await productService.getAll();
  return products.map(p => ({ value: p.id, label: p.name }));
};
export const getCategoryOptions = async (): Promise<{ value: string, label: string }[]> => {
  const categories = await categoryService.getAll();
  return categories.map(c => ({ value: c.id, label: c.name }));
};
export const getBrandOptions = async (): Promise<{ value: string, label: string }[]> => {
  const brands = await brandService.getAll();
  return brands.map(b => ({ value: b.id, label: b.name }));
};
export const getVendorOptions = async (): Promise<{ value: string, label: string }[]> => {
  const vendors = await vendorService.getAll();
  return vendors.map(v => ({ value: v.id, label: v.name }));
};
export const getUserOptions = async (): Promise<{ value: string, label: string }[]> => {
  const users = await userService.getAll();
  return users.map(u => ({ value: u.id, label: u.name }));
};

    