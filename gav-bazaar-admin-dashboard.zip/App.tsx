
import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useLocation, Outlet } from 'react-router-dom';
import { NAVIGATION_ITEMS, ROUTE_PATHS } from './constants';
import type { NavItem } from './types';
import { DashboardPage, OrdersPage, OrderDetailsPage, UsersPage, UserDetailsPage, ProductsPage, CategoriesPage, BrandsPage, VendorsPage } from './pages';
import { HomeIcon } from './components'; // Import any icon for logo or default

const Sidebar: React.FC<{ isOpen: boolean; toggleSidebar: () => void }> = ({ isOpen, toggleSidebar }) => {
  const location = useLocation();

  return (
    <>
      {/* Overlay for mobile */}
      {isOpen && (
        <div
          className="fixed inset-0 z-20 bg-black opacity-50 lg:hidden"
          onClick={toggleSidebar}
        ></div>
      )}
      <aside
        className={`fixed inset-y-0 left-0 z-30 w-64 bg-gradient-to-b from-slate-900 to-slate-800 text-white transform ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0 flex flex-col shadow-lg print:hidden`}
      >
        <div className="flex items-center justify-center h-20 border-b border-slate-700">
           <Link to={ROUTE_PATHS.DASHBOARD} className="flex items-center space-x-2 text-2xl font-bold text-indigo-400 hover:text-indigo-300 transition-colors">
            <HomeIcon className="w-8 h-8" /> 
            <span>Gav Bazaar</span>
          </Link>
        </div>
        <nav className="flex-grow px-4 py-6 space-y-2 overflow-y-auto">
          {NAVIGATION_ITEMS.map((item: NavItem) => (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => { if (window.innerWidth < 1024) toggleSidebar();}} // Close sidebar on mobile after click
              className={`flex items-center px-4 py-2.5 rounded-lg transition-all duration-200 ease-in-out group
                ${
                  location.pathname === item.path || (item.path !== ROUTE_PATHS.DASHBOARD && location.pathname.startsWith(item.path) && item.path.split('/').length <= location.pathname.split('/').length)
                    ? 'bg-indigo-600 text-white shadow-md scale-105'
                    : 'text-slate-300 hover:bg-slate-700 hover:text-white hover:scale-105'
                }`}
            >
              {item.icon && <item.icon className="w-5 h-5 mr-3 transition-transform duration-200 group-hover:rotate-[-5deg]" />}
              <span className="font-medium">{item.name}</span>
            </Link>
          ))}
        </nav>
        <div className="p-4 border-t border-slate-700 text-center">
          <p className="text-xs text-slate-400">&copy; {new Date().getFullYear()} Gav Bazaar Admin</p>
        </div>
      </aside>
    </>
  );
};

const App: React.FC = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };
  
  // Close sidebar on route change for mobile
  const location = useLocation();
  useEffect(() => {
    if (window.innerWidth < 1024) { // lg breakpoint
      setIsSidebarOpen(false);
    }
  }, [location.pathname]);


  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-white shadow-md lg:hidden print:hidden">
          <div className="px-4 py-3 flex justify-between items-center">
            <Link to={ROUTE_PATHS.DASHBOARD} className="text-xl font-bold text-indigo-600">Gav Bazaar</Link>
            <button onClick={toggleSidebar} className="text-gray-600 hover:text-gray-800 focus:outline-none">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7"></path>
              </svg>
            </button>
          </div>
        </header>
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-4 sm:p-6 lg:p-8">
          <Routes>
            <Route path={ROUTE_PATHS.DASHBOARD} element={<DashboardPage />} />
            <Route path={ROUTE_PATHS.ORDERS} element={<OrdersPage />} />
            <Route path={ROUTE_PATHS.ORDER_DETAILS} element={<OrderDetailsPage />} />
            <Route path={ROUTE_PATHS.USERS} element={<UsersPage />} />
            <Route path={ROUTE_PATHS.USER_DETAILS} element={<UserDetailsPage />} />
            <Route path={ROUTE_PATHS.PRODUCTS} element={<ProductsPage />} />
            <Route path={ROUTE_PATHS.CATEGORIES} element={<CategoriesPage />} />
            <Route path={ROUTE_PATHS.CATEGORY_PRODUCTS} element={<CategoriesPage />} /> {/* Route for products within a category */}
            <Route path={ROUTE_PATHS.BRANDS} element={<BrandsPage />} />
            <Route path={ROUTE_PATHS.VENDORS} element={<VendorsPage />} />
            {/* Fallback route */}
            <Route path="*" element={<DashboardPage />} /> 
          </Routes>
          <Outlet /> {/* For nested routes if any in future */}
        </main>
      </div>
    </div>
  );
};

export default App;
