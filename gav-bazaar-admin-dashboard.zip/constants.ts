
import type { NavItem, IconProps, OptionType } from './types';
import { OrderStatus, UserStatus } from './types'; // Changed from "import type"
import { HomeIcon, ShoppingCartIcon, UsersIcon, CubeIcon, TagIcon, BuildingStorefrontIcon, CogIcon, ChartBarIcon } from './components'; 

export const ROUTE_PATHS = {
  DASHBOARD: '/',
  ORDERS: '/orders',
  ORDER_DETAILS: '/orders/:id',
  USERS: '/users',
  USER_DETAILS: '/users/:id',
  PRODUCTS: '/products',
  CATEGORIES: '/categories',
  CATEGORY_PRODUCTS: '/categories/:categoryId/products', // Added for specific route
  BRANDS: '/brands',
  VENDORS: '/vendors',
  SETTINGS: '/settings',
};

export const NAVIGATION_ITEMS: NavItem[] = [
  { path: ROUTE_PATHS.DASHBOARD, name: 'Dashboard', icon: (props: IconProps): React.ReactNode => HomeIcon({...props, className: props.className || "w-5 h-5"}) },
  { path: ROUTE_PATHS.ORDERS, name: 'Orders', icon: (props: IconProps): React.ReactNode => ShoppingCartIcon({...props, className: props.className || "w-5 h-5"}) },
  { path: ROUTE_PATHS.USERS, name: 'Users', icon: (props: IconProps): React.ReactNode => UsersIcon({...props, className: props.className || "w-5 h-5"}) },
  { path: ROUTE_PATHS.PRODUCTS, name: 'Products', icon: (props: IconProps): React.ReactNode => CubeIcon({...props, className: props.className || "w-5 h-5"}) },
  { path: ROUTE_PATHS.CATEGORIES, name: 'Categories', icon: (props: IconProps): React.ReactNode => TagIcon({...props, className: props.className || "w-5 h-5"}) },
  { path: ROUTE_PATHS.BRANDS, name: 'Brands', icon: (props: IconProps): React.ReactNode => BuildingStorefrontIcon({...props, className: props.className || "w-5 h-5"}) },
  { path: ROUTE_PATHS.VENDORS, name: 'Vendors', icon: (props: IconProps): React.ReactNode => ChartBarIcon({...props, className: props.className || "w-5 h-5"}) },
  // { path: ROUTE_PATHS.SETTINGS, name: 'Settings', icon: (props: IconProps): React.ReactNode => CogIcon(props) }, // Example for future use
];

export const ORDER_STATUS_OPTIONS: OptionType[] = Object.values(OrderStatus).map(status => ({ value: status, label: status }));
export const USER_STATUS_OPTIONS: OptionType[] = Object.values(UserStatus).map(status => ({ value: status, label: status }));

export const ITEMS_PER_PAGE_OPTIONS = [5, 10, 20, 50];
