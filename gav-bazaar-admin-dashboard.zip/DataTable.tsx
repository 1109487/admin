
import React, { useState, useMemo, useCallback, useEffect } from 'react'; // Added useEffect
import type { ColumnDefinition } from './types';
import { ITEMS_PER_PAGE_OPTIONS } from './constants';
import { SearchIcon, ArrowDownTrayIcon, Button } from './components'; // Removed ChevronDownIcon as it's not directly used here

interface DataTableProps<T extends { id: string | number }> { // Ensure T has an id
  data: T[];
  columns: ColumnDefinition<T>[];
  title?: string;
  onAddItem?: () => void;
  addItemLabel?: string;
  searchPlaceholder?: string;
  showExport?: boolean;
  defaultItemsPerPage?: number;
}

export function DataTable<T extends { id: string | number }>({ // Ensure T has an id
  data,
  columns,
  title,
  onAddItem,
  addItemLabel = "Add New Item",
  searchPlaceholder = "Search...",
  showExport = true,
  defaultItemsPerPage = 10
}: DataTableProps<T>): React.ReactNode {
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(defaultItemsPerPage);
  const [sortConfig, setSortConfig] = useState<{ key: keyof T | string | null; direction: 'ascending' | 'descending' }>({ key: null, direction: 'ascending' });

  const debouncedSearchTerm = useDebounce(searchTerm, 300);

  const getNestedValue = useCallback(<TItem,>(obj: TItem, path: string): any => {
    return path.split('.').reduce((acc: any, part: string) => {
      if (acc && typeof acc === 'object' && part in acc) {
        return acc[part];
      }
      return undefined;
    }, obj);
  }, []);

  const filteredAndSortedData = useMemo(() => {
    let filtered = data;
    if (debouncedSearchTerm) {
      filtered = data.filter(item =>
        columns.some(column => {
          const value = getNestedValue(item, column.accessor as string);
          return String(value ?? '').toLowerCase().includes(debouncedSearchTerm.toLowerCase());
        })
      );
    }

    if (sortConfig.key) {
      // Create a mutable copy for sorting
      filtered = [...filtered].sort((a, b) => {
        const aValue = getNestedValue(a, sortConfig.key as string);
        const bValue = getNestedValue(b, sortConfig.key as string);

        if (aValue === null || aValue === undefined) return 1;
        if (bValue === null || bValue === undefined) return -1;

        if (typeof aValue === 'number' && typeof bValue === 'number') {
            return sortConfig.direction === 'ascending' ? aValue - bValue : bValue - aValue;
        }
        if (typeof aValue === 'string' && typeof bValue === 'string') {
            return sortConfig.direction === 'ascending' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
        }
        // Fallback for other types or mixed types (basic comparison)
        if (aValue < bValue) return sortConfig.direction === 'ascending' ? -1 : 1;
        if (aValue > bValue) return sort_config.direction === 'ascending' ? 1 : -1;
        return 0;
      });
    }
    return filtered;
  }, [data, columns, debouncedSearchTerm, sortConfig, getNestedValue]);

  const totalItems = filteredAndSortedData.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const paginatedData = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredAndSortedData.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredAndSortedData, currentPage, itemsPerPage]);

  const handleSort = (key: keyof T | string) => {
    let direction: 'ascending' | 'descending' = 'ascending';
    if (sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };

  const exportToCSV = useCallback(() => {
    if (!filteredAndSortedData || filteredAndSortedData.length === 0) return;
    
    const headers = columns.map(col => col.header);
    const rows = filteredAndSortedData.map(item =>
      columns.map(col => {
        if (col.render) {
          const rendered = col.render(item);
          if (typeof rendered === 'string' || typeof rendered === 'number' || typeof rendered === 'boolean') {
            return `"${String(rendered).replace(/"/g, '""')}"`;
          }
          // Attempt to get text from complex ReactNode (experimental, may not cover all cases)
          if (React.isValidElement(rendered) && rendered.props && rendered.props.children) {
             if (typeof rendered.props.children === 'string' || typeof rendered.props.children === 'number') {
                return `"${String(rendered.props.children).replace(/"/g, '""')}"`;
             }
          }
          return ''; 
        }
        const value = getNestedValue(item, col.accessor as string);
        return `"${String(value === null || value === undefined ? '' : value).replace(/"/g, '""')}"`;
      }).join(',')
    );

    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `${title || 'data'}_export.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }, [filteredAndSortedData, columns, title, getNestedValue]);


  return (
    <div className="bg-white shadow-lg rounded-xl p-6">
      <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
        {title && <h2 className="text-2xl font-semibold text-gray-800">{title}</h2>}
        <div className="flex items-center gap-2 w-full sm:w-auto">
           <div className="relative w-full sm:w-64">
            <input
              type="text"
              placeholder={searchPlaceholder}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 w-full transition-shadow duration-200 shadow-sm hover:shadow-md"
              value={searchTerm}
              onChange={(e) => { setSearchTerm(e.target.value); setCurrentPage(1);}}
            />
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <SearchIcon className="h-5 w-5 text-gray-400" />
            </div>
          </div>
          {showExport && (
            <Button onClick={exportToCSV} variant="outline" size="md" leftIcon={<ArrowDownTrayIcon />}>
              Export
            </Button>
          )}
          {onAddItem && (
             <Button onClick={onAddItem} variant="primary" size="md" className="whitespace-nowrap">
              {addItemLabel}
            </Button>
          )}
        </div>
      </div>

      <div className="overflow-x-auto rounded-lg border border-gray-200">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              {columns.map((col) => (
                <th
                  key={String(col.accessor)}
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition-colors"
                  onClick={() => handleSort(col.accessor)}
                >
                  <div className="flex items-center">
                    {col.header}
                    {sortConfig.key === col.accessor && (
                      <span className="ml-1 text-indigo-600">
                        {sortConfig.direction === 'ascending' ? '▲' : '▼'}
                      </span>
                    )}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {paginatedData.length > 0 ? (
              paginatedData.map((item) => ( // Removed index from key as item.id should be unique
                <tr key={item.id} className="hover:bg-gray-50 transition-colors">
                  {columns.map((col) => (
                    <td key={String(col.accessor) + item.id} className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                      {col.render ? col.render(item) : String(getNestedValue(item, col.accessor as string) ?? '')}
                    </td>
                  ))}
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={columns.length} className="px-6 py-12 text-center text-sm text-gray-500">
                  No data available.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="py-4 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center text-sm text-gray-600">
            <span>Show</span>
            <select
              value={itemsPerPage}
              onChange={(e) => {
                setItemsPerPage(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="mx-2 border border-gray-300 rounded-md p-1.5 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
            >
              {ITEMS_PER_PAGE_OPTIONS.map(size => (
                <option key={size} value={size}>{size}</option>
              ))}
            </select>
            <span>entries</span>
            <span className="ml-4 hidden sm:inline">| Total: {totalItems} items</span>
            <span className="ml-4">Page {currentPage} of {totalPages}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              variant="outline"
              size="sm"
            >
              Previous
            </Button>
            {/* Simplified Pagination Display Logic */}
            {(()=>{
                const pageNumbers = [];
                const maxPagesToShow = 5; // Max number of page buttons (excluding prev/next, including ellipsis)
                if (totalPages <= maxPagesToShow) {
                    for (let i = 1; i <= totalPages; i++) pageNumbers.push(i);
                } else {
                    pageNumbers.push(1);
                    let startPage = Math.max(2, currentPage - Math.floor((maxPagesToShow - 3) / 2));
                    let endPage = Math.min(totalPages - 1, currentPage + Math.ceil((maxPagesToShow - 3) / 2));

                    if (currentPage < Math.ceil(maxPagesToShow/2)) {
                        endPage = maxPagesToShow-2;
                    }
                     if (currentPage > totalPages - Math.floor(maxPagesToShow/2)) {
                        startPage = totalPages - (maxPagesToShow-3) ;
                    }

                    if (startPage > 2) pageNumbers.push(-1); // Ellipsis marker

                    for (let i = startPage; i <= endPage; i++) {
                        pageNumbers.push(i);
                    }
                    if (endPage < totalPages - 1) pageNumbers.push(-1); // Ellipsis marker
                    pageNumbers.push(totalPages);
                }
                return pageNumbers.map((pageNumber, index) =>
                    pageNumber === -1 ? 
                    <span key={`ellipsis-${index}`} className="px-2 py-1 text-gray-500">...</span> :
                    <Button
                        key={pageNumber}
                        onClick={() => setCurrentPage(pageNumber)}
                        variant={currentPage === pageNumber ? 'primary' : 'outline'}
                        size="sm"
                        className="w-9 h-9 p-0"
                    >
                        {pageNumber}
                    </Button>
                )
            })()}
            <Button
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              variant="outline"
              size="sm"
            >
              Next
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

// Custom hook for debouncing
function useDebounce<T,>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);
  return debouncedValue;
}

export default DataTable;
