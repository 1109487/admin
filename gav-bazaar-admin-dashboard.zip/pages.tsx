
import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, Link, useLocation as useReactRouterLocation } from 'react-router-dom'; // Renamed useLocation to avoid conflict
import type { Order, User, Product, Category, Brand, Vendor, ColumnDefinition, OrderStatus, UserStatus, OptionType, CrudType, ShippingAddress, OrderItem } from './types';
import { OrderStatus as OrderStatusEnum, UserStatus as UserStatusEnum } from './types';
import { DataTable } from './DataTable';
import { 
    Modal, SearchableSelect, FormInput, FormTextarea, FormSelect, Button, 
    PencilIcon, TrashIcon, EyeIcon, PlusIcon, 
    CubeIcon, TagIcon, BuildingStorefrontIcon, ChartBarIcon, 
    ShoppingCartIcon, UsersIcon // Added ShoppingCartIcon and UsersIcon
} from './components';
import { orderService, userService, productService, categoryService, brandService, vendorService, getDashboardSummary, getProductsByCategoryId, getCategoryOptions, getBrandOptions, getVendorOptions, getUserOptions, getProductOptions } from './services';
import { ORDER_STATUS_OPTIONS, USER_STATUS_OPTIONS, ROUTE_PATHS } from './constants';

// Utility to format currency
const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
};

// Utility to format date
const formatDate = (dateString: string) => {
  if (!dateString) return 'N/A';
  return new Date(dateString).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
};

// Generic Card Component
const InfoCard: React.FC<{ title: string; value: string | number; icon: React.ReactNode; colorClass?: string, onClick?: () => void }> = ({ title, value, icon, colorClass = "bg-indigo-500", onClick }) => (
  <div 
    className={`bg-white shadow-lg rounded-xl p-6 flex items-center space-x-4 transform hover:scale-105 transition-transform duration-300 ${onClick ? 'cursor-pointer' : ''}`}
    onClick={onClick}
    >
    <div className={`p-3 rounded-full ${colorClass} text-white`}>
      {icon}
    </div>
    <div>
      <p className="text-sm text-gray-500">{title}</p>
      <p className="text-2xl font-semibold text-gray-800">{value}</p>
    </div>
  </div>
);

// Dashboard Page
export const DashboardPage: React.FC = () => {
  const [summary, setSummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchSummary = async () => {
      setLoading(true);
      try {
        const data = await getDashboardSummary();
        setSummary(data);
      } catch (error) {
        console.error("Failed to fetch dashboard summary:", error);
        setSummary(null); // Set to null on error to show error message
      } finally {
        setLoading(false);
      }
    };
    fetchSummary();
  }, []);

  if (loading) return <div className="text-center py-10 text-gray-600 animate-pulse">Loading dashboard data...</div>;
  if (!summary) return <div className="text-center py-10 text-red-500">Failed to load dashboard data. Please try again later.</div>;

  const orderColumns: ColumnDefinition<Order>[] = [
    { header: 'Order ID', accessor: 'id', render: item => <Link to={`${ROUTE_PATHS.ORDERS}/${item.id}`} className="text-indigo-600 hover:text-indigo-800 font-medium">{item.id}</Link>},
    { header: 'Customer', accessor: 'userName'},
    { header: 'Date', accessor: 'orderDate', render: item => formatDate(item.orderDate) },
    { header: 'Total', accessor: 'totalAmount', render: item => formatCurrency(item.totalAmount) },
    { header: 'Status', accessor: 'status', render: item => <OrderStatusBadge status={item.status} /> },
  ];

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-semibold text-gray-800">Welcome to Gav Bazaar Admin</h1>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
        <InfoCard title="Total Orders" value={summary.totalOrders} icon={<ShoppingCartIcon className="w-6 h-6"/>} colorClass="bg-blue-500" onClick={() => navigate(ROUTE_PATHS.ORDERS)} />
        <InfoCard title="Pending Orders" value={summary.pendingOrders} icon={<ShoppingCartIcon className="w-6 h-6"/>} colorClass="bg-yellow-500" onClick={() => navigate(ROUTE_PATHS.ORDERS)} />
        <InfoCard title="Total Users" value={summary.totalUsers} icon={<UsersIcon className="w-6 h-6"/>} colorClass="bg-green-500" onClick={() => navigate(ROUTE_PATHS.USERS)} />
        <InfoCard title="Total Products" value={summary.totalProducts} icon={<CubeIcon className="w-6 h-6"/>} colorClass="bg-purple-500" onClick={() => navigate(ROUTE_PATHS.PRODUCTS)} />
        <InfoCard title="Low Stock" value={summary.lowStockProducts} icon={<CubeIcon className="w-6 h-6"/>} colorClass="bg-red-500" onClick={() => navigate(ROUTE_PATHS.PRODUCTS)} />
      </div>

      <div className="bg-white shadow-lg rounded-xl p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-gray-700">Recent Orders</h2>
          <Button variant="outline" size="sm" onClick={() => navigate(ROUTE_PATHS.ORDERS)}>View All Orders</Button>
        </div>
        {summary.recentOrders && summary.recentOrders.length > 0 ? (
          <DataTable
            columns={orderColumns}
            data={summary.recentOrders}
            showExport={false} 
            defaultItemsPerPage={5}
          />
        ) : (
          <p className="text-gray-500 py-4">No recent orders.</p>
        )}
      </div>
      
    </div>
  );
};


// Order Status Badge
const OrderStatusBadge: React.FC<{ status: OrderStatus }> = ({ status }) => {
  let colorClasses = '';
  switch (status) {
    case OrderStatusEnum.PENDING: colorClasses = 'bg-yellow-100 text-yellow-800 border border-yellow-300'; break;
    case OrderStatusEnum.PROCESSING: colorClasses = 'bg-blue-100 text-blue-800 border border-blue-300'; break;
    case OrderStatusEnum.SHIPPED: colorClasses = 'bg-teal-100 text-teal-800 border border-teal-300'; break;
    case OrderStatusEnum.DELIVERED: colorClasses = 'bg-green-100 text-green-800 border border-green-300'; break;
    case OrderStatusEnum.COMPLETED: colorClasses = 'bg-emerald-100 text-emerald-800 border border-emerald-300'; break;
    case OrderStatusEnum.CANCELLED: colorClasses = 'bg-red-100 text-red-800 border border-red-300'; break;
    default: colorClasses = 'bg-gray-100 text-gray-800 border border-gray-300';
  }
  return <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold inline-flex items-center ${colorClasses}`}>{status}</span>;
};

// User Status Badge
const UserStatusBadge: React.FC<{ status: UserStatus }> = ({ status }) => {
  let colorClasses = '';
  switch (status) {
    case UserStatusEnum.ACTIVE: colorClasses = 'bg-green-100 text-green-800 border border-green-300'; break;
    case UserStatusEnum.INACTIVE: colorClasses = 'bg-gray-100 text-gray-800 border border-gray-300'; break;
    case UserStatusEnum.PAID: colorClasses = 'bg-blue-100 text-blue-800 border border-blue-300'; break;
    case UserStatusEnum.UNPAID: colorClasses = 'bg-yellow-100 text-yellow-800 border border-yellow-300'; break;
    default: colorClasses = 'bg-gray-100 text-gray-800 border border-gray-300';
  }
  return <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold inline-flex items-center ${colorClasses}`}>{status}</span>;
};


// Orders Page
export const OrdersPage: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState<string>('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchOrders = async () => {
      setLoading(true);
      const data = await orderService.getAll();
      setOrders(data);
      setLoading(false);
    };
    fetchOrders();
  }, []);

  const filteredOrders = orders.filter(order => 
    filterStatus ? order.status === filterStatus : true
  );

  const columns: ColumnDefinition<Order>[] = [
    { header: 'Order ID', accessor: 'id', render: item => <Link to={`${ROUTE_PATHS.ORDERS}/${item.id}`} className="text-indigo-600 hover:text-indigo-800 font-medium">{item.id}</Link>},
    { header: 'Customer', accessor: 'userName' },
    { header: 'Date', accessor: 'orderDate', render: item => formatDate(item.orderDate) },
    { header: 'Total', accessor: 'totalAmount', render: item => formatCurrency(item.totalAmount) },
    { header: 'Status', accessor: 'status', render: item => <OrderStatusBadge status={item.status} /> },
    {
      header: 'Actions',
      accessor: 'id',
      render: (item) => (
        <Button variant="outline" size="sm" onClick={() => navigate(`${ROUTE_PATHS.ORDERS}/${item.id}`)} leftIcon={<EyeIcon />}>
          Details
        </Button>
      ),
    },
  ];

  if (loading) return <div className="text-center py-10 animate-pulse">Loading orders...</div>;

  return (
    <div>
      <div className="mb-6 flex flex-col sm:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-semibold text-gray-800">Orders</h1>
        <div className="w-full sm:w-64">
          <SearchableSelect
            options={[{ value: '', label: 'All Statuses' }, ...ORDER_STATUS_OPTIONS]}
            value={filterStatus}
            onChange={setFilterStatus}
            placeholder="Filter by status..."
          />
        </div>
      </div>
      <DataTable columns={columns} data={filteredOrders} title="All Orders" />
    </div>
  );
};

// Order Details Page
export const OrderDetailsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (id) {
      const fetchOrder = async () => {
        setLoading(true);
        const data = await orderService.getById(id);
        setOrder(data || null);
        setLoading(false);
      };
      fetchOrder();
    } else {
      setLoading(false);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const handleStatusChange = async (newStatus: OrderStatus) => {
    if (order && id) {
        setIsUpdatingStatus(true);
        const updatedOrder = await orderService.updateStatus(id, newStatus);
        if (updatedOrder) {
            setOrder(updatedOrder);
        }
        setIsUpdatingStatus(false);
    }
  };

  if (loading) return <div className="text-center py-10 animate-pulse">Loading order details...</div>;
  if (!order) return <div className="text-center py-10 text-red-500">Order not found. <Link to={ROUTE_PATHS.ORDERS} className="text-indigo-600 hover:underline">Go back to Orders</Link></div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-2">
        <h1 className="text-3xl font-semibold text-gray-800">Order Details: #{order.id}</h1>
        <Button variant="outline" onClick={() => navigate(ROUTE_PATHS.ORDERS)}>Back to Orders</Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white shadow-lg rounded-xl p-6 space-y-6">
          <h2 className="text-xl font-semibold text-gray-700 border-b pb-3 mb-3">Order Items ({order.items.length})</h2>
          {order.items.map(item => (
            <div key={item.id} className="flex items-start sm:items-center space-x-4 border-b border-gray-100 pb-4 last:border-b-0 last:pb-0 flex-col sm:flex-row">
              <img src={item.imageUrl || `https://picsum.photos/seed/${item.productId}/80/80`} alt={item.productName} className="w-20 h-20 rounded-md object-cover mb-2 sm:mb-0"/>
              <div className="flex-grow">
                <h3 className="font-medium text-gray-800 hover:text-indigo-600 transition-colors">{item.productName}</h3>
                <p className="text-xs text-gray-500">ID: {item.productId}</p>
                <p className="text-sm text-gray-600">Qty: {item.quantity} @ {formatCurrency(item.price)}</p>
              </div>
              <p className="ml-auto font-semibold text-gray-700 text-right sm:text-left">{formatCurrency(item.price * item.quantity)}</p>
            </div>
          ))}
          <div className="text-right mt-4 pt-4 border-t">
            <p className="text-lg font-semibold text-gray-800">Total: {formatCurrency(order.totalAmount)}</p>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white shadow-lg rounded-xl p-6">
            <h2 className="text-xl font-semibold text-gray-700 mb-3">Order Information</h2>
            <p><strong>Date:</strong> {formatDate(order.orderDate)}</p>
            <div className="flex items-center gap-2 mt-1"><strong>Status:</strong> <OrderStatusBadge status={order.status} /></div>
            <div className="mt-4">
                <FormSelect
                    label="Change Status"
                    name="status"
                    options={ORDER_STATUS_OPTIONS}
                    value={order.status}
                    onChange={(e) => handleStatusChange(e.target.value as OrderStatus)}
                    disabled={isUpdatingStatus}
                />
                {isUpdatingStatus && <p className="text-xs text-indigo-600 mt-1 animate-pulse">Updating status...</p>}
            </div>
          </div>

          <div className="bg-white shadow-lg rounded-xl p-6">
            <h2 className="text-xl font-semibold text-gray-700 mb-3">Customer Details</h2>
            <p><strong>Name:</strong> <Link to={`${ROUTE_PATHS.USERS}/${order.userId}`} className="text-indigo-600 hover:underline">{order.userName || 'N/A'}</Link></p>
            <p><strong>User ID:</strong> {order.userId}</p>
          </div>

          <div className="bg-white shadow-lg rounded-xl p-6">
            <h2 className="text-xl font-semibold text-gray-700 mb-3">Shipping Address</h2>
            <address className="not-italic text-gray-600">
              {order.shippingAddress.street}<br />
              {order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.zip}<br />
              {order.shippingAddress.country}
            </address>
          </div>
        </div>
      </div>
    </div>
  );
};


// Users Page
export const UsersPage: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState<string>('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUsers = async () => {
      setLoading(true);
      const data = await userService.getAll();
      setUsers(data);
      setLoading(false);
    };
    fetchUsers();
  }, []);

  const filteredUsers = users.filter(user => 
    filterStatus ? user.status === filterStatus : true
  );

  const columns: ColumnDefinition<User>[] = [
    { header: 'Avatar', accessor: 'avatarUrl', render: item => <img src={item.avatarUrl || `https://picsum.photos/seed/${item.id}/40/40`} alt={item.name} className="w-10 h-10 rounded-full object-cover shadow-sm"/> },
    { header: 'Name', accessor: 'name', render: item => <Link to={`${ROUTE_PATHS.USERS}/${item.id}`} className="text-indigo-600 hover:text-indigo-800 font-medium">{item.name}</Link>},
    { header: 'Email', accessor: 'email' },
    { header: 'Join Date', accessor: 'joinDate', render: item => formatDate(item.joinDate) },
    { header: 'Status', accessor: 'status', render: item => <UserStatusBadge status={item.status} /> },
    {
      header: 'Actions',
      accessor: 'id',
      render: (item) => (
        <Button variant="outline" size="sm" onClick={() => navigate(`${ROUTE_PATHS.USERS}/${item.id}`)} leftIcon={<EyeIcon />}>
          Details
        </Button>
      ),
    },
  ];

  if (loading) return <div className="text-center py-10 animate-pulse">Loading users...</div>;

  return (
    <div>
      <div className="mb-6 flex flex-col sm:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-semibold text-gray-800">Users</h1>
        <div className="w-full sm:w-64">
          <SearchableSelect
            options={[{ value: '', label: 'All Statuses' }, ...USER_STATUS_OPTIONS]}
            value={filterStatus}
            onChange={setFilterStatus}
            placeholder="Filter by status..."
          />
        </div>
      </div>
      <DataTable columns={columns} data={filteredUsers} title="All Users" />
    </div>
  );
};

// User Details Page
export const UserDetailsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (id) {
      const fetchUser = async () => {
        setLoading(true);
        const data = await userService.getById(id);
        setUser(data || null);
        setLoading(false);
      };
      fetchUser();
    } else {
       setLoading(false);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (loading) return <div className="text-center py-10 animate-pulse">Loading user details...</div>;
  if (!user) return <div className="text-center py-10 text-red-500">User not found. <Link to={ROUTE_PATHS.USERS} className="text-indigo-600 hover:underline">Go back to Users</Link></div>;
  
  const userOrderColumns: ColumnDefinition<Pick<Order, 'id' | 'orderDate' | 'status' | 'totalAmount'>>[] = [
    { header: 'Order ID', accessor: 'id', render: item => <Link to={`${ROUTE_PATHS.ORDERS}/${item.id}`} className="text-indigo-600 hover:text-indigo-800 font-medium">{item.id}</Link>},
    { header: 'Date', accessor: 'orderDate', render: item => formatDate(item.orderDate) },
    { header: 'Total', accessor: 'totalAmount', render: item => formatCurrency(item.totalAmount) },
    { header: 'Status', accessor: 'status', render: item => <OrderStatusBadge status={item.status} /> },
  ];
  
  const userWishlistColumns: ColumnDefinition<Product>[] = [
    { header: 'Image', accessor: 'imageUrl', render: item => <img src={item.imageUrl || `https://picsum.photos/seed/${item.id}/60/60`} alt={item.name} className="w-12 h-12 rounded object-cover shadow-sm"/> },
    { header: 'Product Name', accessor: 'name' }, // TODO: Link to product page if exists
    { header: 'Price', accessor: 'price', render: item => formatCurrency(item.price) },
  ];


  return (
    <div className="space-y-6">
       <div className="flex justify-between items-center">
        <h1 className="text-3xl font-semibold text-gray-800">User Details</h1>
        <Button variant="outline" onClick={() => navigate(ROUTE_PATHS.USERS)}>Back to Users</Button>
      </div>
      
      <div className="bg-white shadow-lg rounded-xl p-6 flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6">
        <img src={user.avatarUrl || `https://picsum.photos/seed/${user.id}/120/120`} alt={user.name} className="w-32 h-32 rounded-full object-cover shadow-md border-4 border-white"/>
        <div className="text-center sm:text-left">
          <h2 className="text-2xl font-bold text-gray-800">{user.name}</h2>
          <p className="text-gray-600">{user.email}</p>
          <p className="text-sm text-gray-500">Joined: {formatDate(user.joinDate)}</p>
          <div className="mt-2">
            <UserStatusBadge status={user.status} />
          </div>
        </div>
      </div>

      <div className="bg-white shadow-lg rounded-xl p-6">
        <h3 className="text-xl font-semibold text-gray-700 mb-4">User Orders ({user.orders?.length || 0})</h3>
        {user.orders && user.orders.length > 0 ? (
          <DataTable columns={userOrderColumns} data={user.orders} defaultItemsPerPage={5} showExport={false} />
        ) : (
          <p className="text-gray-500 py-4">This user has no orders.</p>
        )}
      </div>

      <div className="bg-white shadow-lg rounded-xl p-6">
        <h3 className="text-xl font-semibold text-gray-700 mb-4">Wishlist Items ({user.wishlist?.length || 0})</h3>
        {user.wishlist && user.wishlist.length > 0 ? (
          <DataTable columns={userWishlistColumns} data={user.wishlist} defaultItemsPerPage={5} showExport={false} />
        ) : (
          <p className="text-gray-500 py-4">This user's wishlist is empty.</p>
        )}
      </div>
    </div>
  );
};


// --- Generic CRUD Page Logic ---
interface CrudPageProps<T extends { id: string; name?: string }> {
  title: string;
  itemType: CrudType;
  service: {
    getAll: () => Promise<T[]>;
    getById: (id: string) => Promise<T | undefined>;
    create: (data: Omit<T, 'id'>) => Promise<T>;
    update: (id: string, data: Partial<T>) => Promise<T | undefined>;
    delete: (id: string) => Promise<boolean>;
  };
  columns: ColumnDefinition<T>[];
  getFormFields: (
    currentData: Partial<T>,
    updateField: <K extends keyof T>(name: K, value: T[K]) => void,
    options?: any
  ) => React.ReactNode;
  initialFormData: Omit<T, 'id'>;
  additionalDataForForms?: () => Promise<any>;
}

const GenericCrudPage = <T extends { id: string; name?: string }> ({
  title, itemType, service, columns: propColumns, getFormFields, initialFormData, additionalDataForForms
}: CrudPageProps<T>) => {
  const [items, setItems] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [editingItem, setEditingItem] = useState<T | null>(null);
  const [formData, setFormData] = useState<Partial<T>>(initialFormData);
  const [formOptions, setFormOptions] = useState<any>({});
  const navigate = useNavigate();

  const loadItems = useCallback(async () => {
    setLoading(true);
    try {
        const data = await service.getAll();
        setItems(data);
    } catch(error) {
        console.error(`Failed to load ${itemType}s:`, error);
    } finally {
        setLoading(false);
    }
  }, [service, itemType]);

  useEffect(() => {
    loadItems();
    if (additionalDataForForms) {
        additionalDataForForms().then(options => setFormOptions(options)).catch(err => console.error("Failed to load form options:", err));
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loadItems]); // Removed additionalDataForForms from deps to prevent re-fetch on every render

  const updateField = <K extends keyof T,>(name: K, value: T[K] | T[K][] ) => { // Allow T[K][] for tags
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const openModalForCreate = () => {
    setEditingItem(null);
    setFormData(initialFormData);
    setIsModalOpen(true);
  };

  const openModalForEdit = (item: T) => {
    setEditingItem(item);
    setFormData(item); 
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingItem(null);
    setIsSubmitting(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
        if (editingItem) {
        await service.update(editingItem.id, formData);
        } else {
        await service.create(formData as Omit<T, 'id'>);
        }
        loadItems();
        closeModal();
    } catch (error) {
        console.error(`Failed to save ${itemType}:`, error);
        // Potentially show an error message to the user
    } finally {
        setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm(`Are you sure you want to delete this ${itemType.toLowerCase()}? This action cannot be undone.`)) {
      setLoading(true); // Indicate loading during delete
      try {
        await service.delete(id);
        loadItems(); // Reload items, which will also set loading to false
      } catch(error) {
        console.error(`Failed to delete ${itemType}:`, error);
        setLoading(false); // Reset loading on error
      }
    }
  };

  const actionColumn: ColumnDefinition<T> = {
    header: 'Actions',
    accessor: 'id',
    render: (item) => (
      <div className="flex space-x-2">
        <Button variant="outline" size="sm" onClick={() => openModalForEdit(item)} leftIcon={<PencilIcon />} disabled={loading}>Edit</Button>
        <Button variant="danger" size="sm" onClick={() => handleDelete(item.id)} leftIcon={<TrashIcon />} disabled={loading}>Delete</Button>
        {itemType === 'Category' && (
           <Button variant="ghost" size="sm" onClick={() => navigate(ROUTE_PATHS.CATEGORY_PRODUCTS.replace(':categoryId', item.id))} leftIcon={<EyeIcon />} disabled={loading}>Products</Button>
        )}
      </div>
    ),
  };

  const combinedColumns = [...propColumns, actionColumn];

  if (loading && items.length === 0) return <div className="text-center py-10 animate-pulse">Loading {itemType.toLowerCase()}s...</div>;
  
  return (
    <div>
      <DataTable
        columns={combinedColumns}
        data={items}
        title={title}
        onAddItem={openModalForCreate}
        addItemLabel={`Add New ${itemType}`}
      />
      <Modal isOpen={isModalOpen} onClose={closeModal} title={editingItem ? `Edit ${itemType}` : `Add New ${itemType}`}>
        <form onSubmit={handleSubmit} className="space-y-4">
          {getFormFields(formData, updateField, formOptions)}
          <div className="flex justify-end space-x-3 pt-4 mt-2 border-t border-gray-200">
            <Button type="button" variant="secondary" onClick={closeModal} disabled={isSubmitting}>Cancel</Button>
            <Button type="submit" variant="primary" isLoading={isSubmitting} disabled={isSubmitting}>
                {editingItem ? 'Save Changes' : `Create ${itemType}`}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};


// Products Page
export const ProductsPage: React.FC = () => {
  const productColumns: ColumnDefinition<Product>[] = [
    { header: 'Image', accessor: 'imageUrl', render: item => <img src={item.imageUrl || `https://picsum.photos/seed/${item.id}/60/60`} alt={item.name} className="w-12 h-12 rounded object-cover shadow-sm"/> },
    { header: 'Name', accessor: 'name' },
    { header: 'Category', accessor: 'categoryName' },
    { header: 'Price', accessor: 'price', render: item => formatCurrency(item.price) },
    { header: 'Stock', accessor: 'stock' },
    { header: 'SKU', accessor: 'sku' },
  ];

  const getProductFormFields = (
        currentData: Partial<Product>, 
        updateProductField: <K extends keyof Product>(name: K, value: Product[K] | Product[K][]) => void,
        options?: any
    ) => (
    <>
      <FormInput label="Product Name" name="name" value={currentData?.name || ''} onChange={(e) => updateProductField('name', e.target.value)} required />
      <FormTextarea label="Description" name="description" value={currentData?.description || ''} onChange={(e) => updateProductField('description', e.target.value)} />
      <FormInput label="Price" name="price" type="number" step="0.01" value={currentData?.price || ''} onChange={(e) => updateProductField('price', parseFloat(e.target.value) || 0)} required />
      <FormInput label="Stock Quantity" name="stock" type="number" value={currentData?.stock || ''} onChange={(e) => updateProductField('stock', parseInt(e.target.value,10) || 0)} required />
      <FormInput label="SKU" name="sku" value={currentData?.sku || ''} onChange={(e) => updateProductField('sku', e.target.value)} required placeholder="e.g. PROD-001"/>
      <FormInput label="Image URL" name="imageUrl" value={currentData?.imageUrl || ''} onChange={(e) => updateProductField('imageUrl', e.target.value)} placeholder="https://picsum.photos/seed/newprod/200/200"/>
      
      <div className="mb-4">
          <label htmlFor="categoryId" className="block text-sm font-medium text-gray-700 mb-1">Category</label>
          <SearchableSelect
              id="categoryId"
              options={options?.categories || []}
              value={currentData?.categoryId}
              onChange={(val) => {
                  updateProductField('categoryId', val);
                  const selectedCategory = options?.categories?.find((c: OptionType) => c.value === val);
                  if (selectedCategory) updateProductField('categoryName', selectedCategory.label);
              }}
              placeholder="Select Category"
          />
      </div>
      <div className="mb-4">
           <label htmlFor="brandId" className="block text-sm font-medium text-gray-700 mb-1">Brand</label>
          <SearchableSelect
              id="brandId"
              options={options?.brands || []}
              value={currentData?.brandId}
              onChange={(val) => {
                  updateProductField('brandId', val);
                  const selectedBrand = options?.brands?.find((b:OptionType) => b.value === val);
                  if (selectedBrand) updateProductField('brandName', selectedBrand.label);
              }}
              placeholder="Select Brand"
          />
      </div>
      <div className="mb-4">
          <label htmlFor="vendorId" className="block text-sm font-medium text-gray-700 mb-1">Vendor</label>
          <SearchableSelect
              id="vendorId"
              options={options?.vendors || []}
              value={currentData?.vendorId}
              onChange={(val) => {
                  updateProductField('vendorId', val);
                  const selectedVendor = options?.vendors?.find((v:OptionType) => v.value === val);
                  if (selectedVendor) updateProductField('vendorName', selectedVendor.label);
              }}
              placeholder="Select Vendor"
          />
      </div>
      <FormInput 
        label="Tags (comma-separated)" 
        name="tags-input" // Name attribute for HTML element, not directly T's key
        value={currentData?.tags?.join(', ') || ''} 
        onChange={(e) => updateProductField('tags', e.target.value.split(',').map(s => s.trim()).filter(s=>s))} 
        placeholder="e.g. featured, summer, electronics"
      />
    </>
  );

  const initialProductData: Omit<Product, 'id'> = {
    name: '', description: '', price: 0, stock: 0, categoryId: '', sku: '', categoryName: '',
    brandId: '', brandName: '', vendorId: '', vendorName: '', imageUrl: '', tags: []
  };
  
  const fetchProductFormOptions = async () => {
    const [categories, brands, vendors] = await Promise.all([
      getCategoryOptions(),
      getBrandOptions(),
      getVendorOptions()
    ]);
    return { categories, brands, vendors };
  };

  return (
    <GenericCrudPage<Product>
      title="Products"
      itemType="Product"
      service={productService}
      columns={productColumns}
      getFormFields={getProductFormFields}
      initialFormData={initialProductData}
      additionalDataForForms={fetchProductFormOptions}
    />
  );
};

// Categories Page
export const CategoriesPage: React.FC = () => {
  const { categoryId } = useParams<{ categoryId?: string }>();
  const reactRouterLocation = useReactRouterLocation(); // Use renamed hook
  const [productsInCategory, setProductsInCategory] = useState<Product[] | null>(null);
  const [categoryName, setCategoryName] = useState<string>('');
  const [loadingProducts, setLoadingProducts] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (categoryId && reactRouterLocation.pathname.endsWith('/products')) {
      const fetchProducts = async () => {
        setLoadingProducts(true);
        const products = await getProductsByCategoryId(categoryId);
        setProductsInCategory(products);
        const cat = await categoryService.getById(categoryId);
        setCategoryName(cat?.name || 'Unknown Category');
        setLoadingProducts(false);
      };
      fetchProducts();
    } else {
      setProductsInCategory(null); 
    }
  }, [categoryId, reactRouterLocation.pathname]);

  const categoryColumns: ColumnDefinition<Category>[] = [
    { header: 'Name', accessor: 'name' },
    { header: 'Description', accessor: 'description' },
    { header: 'Product Count', accessor: 'productCount', render: item => item.productCount || 0 },
  ];
  
  const getCategoryFormFields = (
    currentData: Partial<Category>,
    updateCategoryField: <K extends keyof Category>(name: K, value: Category[K]) => void
    ) => (
    <>
      <FormInput label="Category Name" name="name" value={currentData?.name || ''} onChange={(e) => updateCategoryField('name', e.target.value)} required />
      <FormTextarea label="Description" name="description" value={currentData?.description || ''} onChange={(e) => updateCategoryField('description', e.target.value)} />
    </>
  );
  
  const initialCategoryData: Omit<Category, 'id'> = { name: '', description: '' };

  if (productsInCategory || loadingProducts) {
    const productCols: ColumnDefinition<Product>[] = [
        { header: 'Image', accessor: 'imageUrl', render: item => <img src={item.imageUrl || `https://picsum.photos/seed/${item.id}/60/60`} alt={item.name} className="w-12 h-12 rounded object-cover shadow-sm"/> },
        { header: 'Name', accessor: 'name' }, // TODO: Link to product page
        { header: 'Price', accessor: 'price', render: item => formatCurrency(item.price) },
        { header: 'Stock', accessor: 'stock' },
    ];
    return (
      <div>
        <div className="mb-6 flex flex-col sm:flex-row justify-between items-center gap-2">
          <h1 className="text-3xl font-semibold text-gray-800">Products in {categoryName}</h1>
          <Button variant="outline" onClick={() => navigate(ROUTE_PATHS.CATEGORIES)}>Back to Categories</Button>
        </div>
        {loadingProducts ? <div className="text-center py-10 animate-pulse">Loading products...</div> : 
        <DataTable columns={productCols} data={productsInCategory || []} title={`Products in ${categoryName}`} />}
      </div>
    );
  }

  return (
    <GenericCrudPage<Category>
      title="Categories"
      itemType="Category"
      service={categoryService}
      columns={categoryColumns}
      getFormFields={getCategoryFormFields}
      initialFormData={initialCategoryData}
    />
  );
};

// Brands Page
export const BrandsPage: React.FC = () => {
  const brandColumns: ColumnDefinition<Brand>[] = [
    { header: 'Logo', accessor: 'logoUrl', render: item => <img src={item.logoUrl || `https://picsum.photos/seed/${item.id}/40/40`} alt={item.name} className="w-10 h-10 rounded-full object-contain bg-gray-100 p-0.5 shadow-sm"/> },
    { header: 'Name', accessor: 'name' },
    { header: 'Product Count', accessor: 'productCount', render: item => item.productCount || 0 },
  ];

  const getBrandFormFields = (
    currentData: Partial<Brand>,
    updateBrandField: <K extends keyof Brand>(name: K, value: Brand[K]) => void
    ) => (
    <>
      <FormInput label="Brand Name" name="name" value={currentData?.name || ''} onChange={(e) => updateBrandField('name', e.target.value)} required />
      <FormInput label="Logo URL" name="logoUrl" value={currentData?.logoUrl || ''} onChange={(e) => updateBrandField('logoUrl', e.target.value)} placeholder="https://picsum.photos/seed/newbrand/40/40"/>
    </>
  );
  
  const initialBrandData: Omit<Brand, 'id'> = { name: '', logoUrl: '' };

  return (
    <GenericCrudPage<Brand>
      title="Brands"
      itemType="Brand"
      service={brandService}
      columns={brandColumns}
      getFormFields={getBrandFormFields}
      initialFormData={initialBrandData}
    />
  );
};

// Vendors Page
export const VendorsPage: React.FC = () => {
  const vendorColumns: ColumnDefinition<Vendor>[] = [
    { header: 'Name', accessor: 'name' },
    { header: 'Contact Email', accessor: 'contactEmail' },
    { header: 'Phone', accessor: 'phone', render: item => item.phone || 'N/A'},
    { header: 'Product Count', accessor: 'productCount', render: item => item.productCount || 0 },
  ];

  const getVendorFormFields = (
    currentData: Partial<Vendor>,
    updateVendorField: <K extends keyof Vendor>(name: K, value: Vendor[K]) => void
    ) => (
    <>
      <FormInput label="Vendor Name" name="name" value={currentData?.name || ''} onChange={(e) => updateVendorField('name', e.target.value)} required />
      <FormInput label="Contact Email" name="contactEmail" type="email" value={currentData?.contactEmail || ''} onChange={(e) => updateVendorField('contactEmail', e.target.value)} required />
      <FormInput label="Phone" name="phone" type="tel" value={currentData?.phone || ''} onChange={(e) => updateVendorField('phone', e.target.value)} />
    </>
  );
  
  const initialVendorData: Omit<Vendor, 'id'> = { name: '', contactEmail: '', phone: '' };
  
  return (
    <GenericCrudPage<Vendor>
      title="Vendors"
      itemType="Vendor"
      service={vendorService}
      columns={vendorColumns}
      getFormFields={getVendorFormFields}
      initialFormData={initialVendorData}
    />
  );
};
